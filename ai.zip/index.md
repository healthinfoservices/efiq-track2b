# Home - HL7 v2 SIU to FHIR Appointment - AU Core (Proof of Concept) v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/siu2fhir-au/ImplementationGuide/example.fhir.siu2fhir.au | *Version*:0.1.0 |
| Draft as of 2026-10-28 | *Computable Name*:SIU2FHIRAUCore |

### Purpose

This implementation guide documents a **proof of concept** that turns an HL7 v2 scheduling feed into FHIR R4 resources conforming to **AU Core 2.0.0**. A Python ingestion service receives SIU S12, S13, S14 and S15 messages, converts them, and writes them to a HAPI FHIR server. A web front end (planned: Vue/Vuetify) reads appointments directly from that server.

This guide describes a proof of concept that uses
**simulated data only**. It is not intended for clinical use. IHI, HPI-I and Medicare numbers in the examples are
**synthetic**: they pass the AU Base format checks but were not issued to anyone. The canonical URL, local identifier systems and local code systems are
`example.org`placeholders.

### What conforms to what

| | | |
| :--- | :--- | :--- |
| Patient | [AU Core Patient](https://hl7.org.au/fhir/core/StructureDefinition-au-core-patient.html) | PID |
| Practitioner | [AU Core Practitioner](https://hl7.org.au/fhir/core/StructureDefinition-au-core-practitioner.html) | AIP-3 |
| Location | [AU Core Location](https://hl7.org.au/fhir/core/StructureDefinition-au-core-location.html) | AIL-3, AIL-4 |
| Organization | [AU Core Organization](https://hl7.org.au/fhir/core/StructureDefinition-au-core-organization.html) | AIL-3.4 facility, looked up on the FHIR server |
| Appointment | [SIU AU Appointment](StructureDefinition-siu-au-appointment.md)(this guide) | SCH, AIS, AIG, AIL, AIP, NTE |

AU Core 2.0.0 has no Appointment profile, so this guide defines one whose participants reference the AU Core resources.

### Scope

| | | |
| :--- | :--- | :--- |
| S12 | New appointment booking | Create the Appointment (or update it if the ID already exists) |
| S13 | Reschedule | Rebuild the Appointment with the new times |
| S14 | Modification | Rebuild the Appointment with the changed details |
| S15 | Cancellation | Set status to`cancelled`and record the reason |

### Dependencies








### How to read this guide

* [AU Core Conformance](au-core.md): what changes compared with a plain FHIR R4 mapping, and why.
* [Mapping](mapping.md): field-level HL7 v2 to FHIR rules.
* [Local Registry](registry.md): local configuration (location type translations), and how facilities and MRN namespaces are handled without it.
* [Processing](messaging.md): matching, ordering and acknowledgements.
* [Worked Example](lifecycle.md): one appointment through S12 → S13 → S14 → S15, plus a missing-data example.
* [Building This Guide](building.md): local build and the GitHub Pages workflow.
* [Open Issues](open-issues.md).

